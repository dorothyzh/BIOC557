Human islets · type 2 diabetes
Small teaching cohort: 3 non-diabetic and 3 T2D donors. Age, sex and islet purity can confound the comparison. Use it to explore methods, not to establish a clinical signature. Untargeted metabolite features are m/z–retention-time signals, not confirmed compound IDs.

Same published RRID donor identity across RNA, proteomics and metabolomics. Technical metabolomics injections are collapsed per donor.

Run run_demo.R in RStudio. data/provenance.json records transformations and source hashes.
