BIOC557: Human pancreatic islets: three molecular views

1. Install R and RStudio Desktop once.
2. Extract this entire ZIP. Double-click BIOC557.Rproj.
3. Open START_HERE.R and click Source.

Missing packages install automatically on the first run. Keep RStudio open.
The finished report is BIOC557_Default_Lab.html. Figures and tables are in outputs/.
For later runs, open BIOC557_Default_Lab.Rmd and click Knit.
All demo data are included; you do not need to edit paths or parameters.
The default is PCA with 100 features per view and unit-variance scaling; MOFA is not installed for this default report.
