# Open this folder as your RStudio working directory.
# First time: source("R/install_packages.R")
source("R/lab_core.R")
source("R/lab_plots.R")
meta <- read.csv("data/metadata.csv", check.names=FALSE)
view_names <- c("Proteomics", "RNA", "Metabolomics")
views <- setNames(lapply(view_names, function(v) {
  d <- read.csv(paste0("data/",v,".csv"), check.names=FALSE)
  x <- as.matrix(d[match(meta$sample_id,d$sample_id),-1,drop=FALSE])
  storage.mode(x) <- "double"; rownames(x) <- meta$sample_id; x
}),view_names)
study <- list(metadata=meta,views=views,levels=unique(meta$group))
lab <- run_lab(study,model_features=100)
mofa <- fit_lab_mofa(lab,factors=2,runtime="managed")
plot_integration(lab,mofa)
plot_factor_contributions(mofa)
saveRDS(list(lab=lab,mofa=mofa),"analysis.rds")
