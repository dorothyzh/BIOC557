BIOC557 upload format examples

These are synthetic format examples, not biological study data.

1. Upload metadata.csv plus proteomics.csv and rna.csv.
2. Optionally add metabolomics.csv.
3. Leave Already transformed selected for all example files.
4. Use Human gene symbols to try the available gene catalogs, or Other to skip enrichment.
5. Check & load data, then Start analysis.

The RNA matrix is also provided as rna_features_in_rows.csv to show the alternative layout. Use one RNA file at a time.
All files share 20 sample IDs and two groups of 10.
For your own data: unique sample IDs, two groups with >=3 samples each, 4–5000 features per view, 8 MB total. Blank/NA/NaN entries are missing. Normalize RNA library sizes before upload. Files remain in the browser.
