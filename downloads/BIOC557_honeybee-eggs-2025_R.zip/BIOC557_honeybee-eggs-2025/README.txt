Honeybee eggs · seasonal molecular patterns
Two measured views: lipidomics and metabolomics. Positive/negative metabolite ion modes are combined into one layer. Month is an observational seasonal comparison; collection date, beekeeper and environment can covary. Source compound labels are putative annotations. Human GO/KEGG catalogs are not applied to these bee features.

Exact queen ID shared by the lipid-positive and metabolite-positive/negative source tables and queen metadata. Queen identity links egg pools across assays.

Run run_demo.R in RStudio. data/provenance.json records transformations and source hashes.
