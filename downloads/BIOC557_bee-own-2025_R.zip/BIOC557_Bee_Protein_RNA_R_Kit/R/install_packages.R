# Run once in R / RStudio. No Python commands are needed.
cran<-c('ggplot2','jsonlite','knitr','rmarkdown','ggrepel','patchwork','reticulate')
missing<-cran[!vapply(cran,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing)) install.packages(missing,repos='https://cloud.r-project.org')
if(!requireNamespace('MOFA2',quietly=TRUE)) {
  if(!requireNamespace('BiocManager',quietly=TRUE)) install.packages('BiocManager',repos='https://cloud.r-project.org')
  BiocManager::install('MOFA2',ask=FALSE,update=FALSE)
}
if(utils::packageVersion('reticulate') < '1.41') install.packages('reticulate',repos='https://cloud.r-project.org')
message('Ready. MOFA2 will manage its calculation dependencies on the first managed run.')

if(!requireNamespace("edgeR",quietly=TRUE)) {
 if(!requireNamespace("BiocManager",quietly=TRUE))install.packages("BiocManager",repos="https://cloud.r-project.org")
 BiocManager::install("edgeR",ask=FALSE,update=FALSE)
}
