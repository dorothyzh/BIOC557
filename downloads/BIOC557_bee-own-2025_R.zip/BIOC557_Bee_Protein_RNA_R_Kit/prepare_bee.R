# BIOC557: the author's HBB/CRA honeybee protein + RNA teaching cohort.
# Run from the extracted R kit. Samples are matched through the study crosswalk.
prepare_bee <- function(source_dir='source_data',output_dir='data',max_features=1200) {
  for(pkg in c('edgeR','jsonlite'))if(!requireNamespace(pkg,quietly=TRUE))
    stop('Install ',pkg,' first; see R/install_packages.R.')
  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  read_matrix<-function(file){d<-read.csv(file,check.names=FALSE);ids<-d[[1]];x<-as.matrix(d[,-1,drop=FALSE]);storage.mode(x)<-'double';rownames(x)<-ids;if(anyDuplicated(ids))stop('Duplicate feature IDs.');x}
  meta<-read.csv(file.path(source_dir,'metadata.csv'),check.names=FALSE)
  p<-read_matrix(file.path(source_dir,'protein_linear.csv'))
  counts<-read_matrix(file.path(source_dir,'RNA_counts.csv'))
  pm<-read.csv(file.path(source_dir,'protein_to_gene.csv'))
  rm<-read.csv(file.path(source_dir,'RNA_to_gene.csv'))
  source<-jsonlite::fromJSON(file.path(source_dir,'source_provenance.json'),simplifyVector=FALSE)
  gene_labels<-jsonlite::fromJSON(file.path(source_dir,'gene_labels.json'),simplifyVector=FALSE)
  stopifnot(nrow(meta)==60,!anyDuplicated(meta$sample_id),setequal(meta$sample_id,colnames(p)),
            setequal(meta$sample_id,colnames(counts)),all(counts>=0),all(counts%%1==0))
  make_view<-function(name,x,unit){
    variance<-apply(x,2,var,na.rm=TRUE);keep<-colMeans(is.na(x))<=.5 & is.finite(variance) & variance>1e-12
    x<-x[,keep,drop=FALSE];ix<-order(-variance[keep],seq_len(sum(keep)))
    x<-x[,head(ix,max_features),drop=FALSE]
    list(name=name,sample_ids=rownames(x),features=colnames(x),values=x,input_scale='transformed',unit=unit)
  }
  split_median<-function(x,gene){
    ix<-split(seq_along(gene),gene)
    y<-do.call(rbind,lapply(ix,function(i)apply(x[i,,drop=FALSE],2,function(a)if(all(is.na(a)))NA_real_ else median(a,na.rm=TRUE))))
    rownames(y)<-names(ix);colnames(y)<-colnames(x);y
  }
  output<-list()
  for(tissue in c('H','A','G')) {
    m<-meta[meta$tissue==tissue,,drop=FALSE];m<-m[order(match(m$group,c('Blueberry','Cranberry')),m$year,m$replicate),]
    ids<-m$sample_id;stopifnot(nrow(m)==20,all(table(m$group)==10),!anyDuplicated(m$apiary_year))
    pp<-p[match(pm$protein_id,rownames(p)),ids,drop=FALSE];pp[pp<=0]<-NA_real_;pp<-log2(pp)
    pp<-split_median(pp,pm$gene_id)
    # TMM factors and library sizes use all assigned source genes, before filtering.
    raw<-counts[,ids,drop=FALSE];dge<-edgeR::calcNormFactors(edgeR::DGEList(raw),method='TMM')
    effective_library<-dge$samples$lib.size*dge$samples$norm.factors
    mapped<-raw[match(rm$rna_id,rownames(raw)),,drop=FALSE]
    merged<-rowsum(mapped,group=rm$gene_id,reorder=TRUE)
    cpm<-sweep(merged,2,effective_library,FUN='/')*1e6
    expressed<-rowSums(cpm>=1)>=ceiling(ncol(cpm)/2)
    rr<-log2(cpm[expressed,,drop=FALSE]+1)
    views<-list(make_view('Proteomics',t(pp),'log2 abundance; median of mapped proteins per gene'),
                make_view('RNA',t(rr),'log2(TMM-normalized CPM + 1)'))
    m$rna_library_size<-dge$samples$lib.size;m$rna_TMM_factor<-dge$samples$norm.factors
    full_tissue<-c(H='Head',A='Abdomen',G='Midgut')[[tissue]]
    slug<-c(H='head',A='abdomen',G='gut')[[tissue]];id<-paste0('bee-own-',slug,'-2025')
    src<-source;src$papers<-list(list(title='Omics Insights Into the Effects of Highbush Blueberry and Cranberry Crop Agroecosystems on Honey Bee Health and Physiology',journal='Proteomics',year=2025,issue_year=2026,url='https://doi.org/10.1002/pmic.70033'))
    src$repository<-'https://doi.org/10.25345/C56D5PP90'
    src$processing<-c('Keep exactly the 60 exposed t2 tissue pools from the explicit protein/RNA crosswalk, then analyze one tissue at a time (20 samples, 10 per crop).',
      'Protein: nonpositive source abundance becomes missing before log2; aggregate exact RefSeq-to-gene mappings by median of observed log2 protein values within each gene.',
      'RNA: remove HTSeq auxiliary __ rows; TMM normalization uses all assigned gene counts within the selected tissue. Sum exact gene aliases, then log2(TMM CPM+1). Keep genes with CPM>=1 in at least half the tissue samples.',
      'Keep features observed in at least half the tissue samples and with nonzero variance, then at most 1200 per view ranked by variance without crop labels. The model applies its own subsequent missingness/feature filter.',
      'Do not use the removeTissue/removeYear residualized tables, significance-filtered results, or source-imputed protein matrices. This is a new MOFA teaching analysis, not a reproduction of the paper WGCNA.')
    ids_shared<-Reduce(intersect,lapply(views,function(v)v$features))
    pairs<-lapply(ids_shared,function(g)list(protein_feature_id=g,rna_feature_id=g,
        gene_symbol=if(is.null(gene_labels[[g]]))g else paste0(gene_labels[[g]],' (',g,')')))
    d<-list(title=paste0('Honeybee ',tolower(full_tissue),': proteins and RNA'),sample_ids=ids,groups=m$group,
      group_order=c('Blueberry','Cranberry'),metadata=m,views=views,source=src,
      shared_gene_pairs=pairs,
      pairing_unit='Exact apiary-year and tissue pool matched by the author\u2019s protein/RNA crosswalk. Twelve bees per published tissue pool; a pool is one replicate.',
      gene_labels=gene_labels,
      teaching=list(id=id,family='bee-own-2025',download_id='bee-own-2025',tissue=full_tissue,species='Apis mellifera',year=2025,
        sample_label='matched tissue pools',default_factors=3,annotation_mode='bee_genes',
        description=paste0('HBB/CRA field study. ',full_tissue,': 10 blueberry and 10 cranberry apiary-year pools, sampled in 2020 and 2021.'),
        warning='One tissue per analysis: the three tissues from one apiary-year are related measurements. Crop, region and acquisition plate can covary. The classroom crop tests are unadjusted and observational. Protein features summarize mapped proteins per gene; RNA and protein keep independent feature pools.',
        shared_gene_pool=length(ids_shared)))
    dest<-file.path(output_dir,id);dir.create(dest,showWarnings=FALSE,recursive=TRUE)
    jsonlite::write_json(d,file.path(dest,'study.json'),auto_unbox=TRUE,na='null',digits=8,matrix='rowmajor')
    write.csv(m,file.path(dest,'metadata.csv'),row.names=FALSE)
    for(v in views)write.csv(data.frame(sample_id=ids,v$values,check.names=FALSE),file.path(dest,paste0(v$name,'.csv')),row.names=FALSE,na='')
    jsonlite::write_json(src,file.path(dest,'provenance.json'),auto_unbox=TRUE,pretty=TRUE)
    output[[slug]]<-d
    message(full_tissue,': ',length(ids),' matched pools; ',paste(sapply(views,function(v)length(v$features)),collapse=' + '),' features; ',length(ids_shared),' genes in both input pools.')
  }
  invisible(output)
}
