# First time: source("R/install_packages.R")
# Set this extracted folder as your RStudio working directory.
tissue <- "head" # choose "head", "abdomen" or "gut"
source("R/lab_core.R")
source("R/lab_plots.R")
source("R/lab_explore.R")
folder<-paste0("data/bee-own-",tissue,"-2025/")
meta<-read.csv(paste0(folder,"metadata.csv"),check.names=FALSE)
view_names<-c("Proteomics","RNA")
views<-setNames(lapply(view_names,function(name){
 d<-read.csv(paste0(folder,name,".csv"),check.names=FALSE)
 stopifnot(!anyDuplicated(d$sample_id),setequal(d$sample_id,meta$sample_id))
 x<-as.matrix(d[match(meta$sample_id,d$sample_id),-1,drop=FALSE])
 storage.mode(x)<-"double";rownames(x)<-meta$sample_id;x
}),view_names)
study<-list(metadata=meta,views=views,levels=unique(meta$group))
lab<-run_lab(study,model_features=100,feature_scaling="unit_variance",mofa_center=TRUE)
dir.create("outputs",showWarnings=FALSE)
mofa<-fit_lab_mofa(lab,factors=3,scale_views=FALSE,runtime="managed",
                   outfile=paste0("outputs/",tissue,"_MOFA.hdf5"))
print(plot_integration(lab,mofa))
print(plot_factor_contributions(mofa))
print(plot_gene_pair(lab))
net<-factor_network(lab,mofa,factor=1,top_per_view=6)
print(plot_factor_network(net))
annotations<-jsonlite::fromJSON("bee_annotations.json",simplifyVector=FALSE)
ora<-factor_enrichment(lab,mofa,annotations,factor=1,view="RNA",catalog="GO_BP",top_n=20)
print(plot_pathway_results(ora))
saveRDS(list(lab=lab,mofa=mofa),paste0("outputs/",tissue,"_analysis.rds"))
# Try factors=2, 4, 5 or 6 and rerun.
# Feature scaling: "unit_variance", "pareto", "none"; mofa_center: TRUE/FALSE.
# For bee pathways use catalog="Bee_KEGG" above.
# export_publication(plot_factor_contributions(mofa),paste0("outputs/",tissue,"_factors"))
