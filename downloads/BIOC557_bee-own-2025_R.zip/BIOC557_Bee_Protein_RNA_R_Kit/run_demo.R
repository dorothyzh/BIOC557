# First time: source("R/install_packages.R")
source("R/lab_core.R")
source("R/lab_plots.R")
source("R/lab_explore.R")
settings<-jsonlite::fromJSON("default_settings.json",simplifyVector=FALSE)
tissue<-"head" # choose "head", "abdomen" or "gut"
id<-paste0("bee-own-",tissue,"-2025")
study_file<-paste0("data/",id,"/study.json")
p<-settings[[id]]
study_json<-jsonlite::fromJSON(study_file,simplifyVector=FALSE)
meta<-do.call(rbind,lapply(study_json$metadata,as.data.frame,stringsAsFactors=FALSE))
view_names<-vapply(study_json$views,function(v)v$name,character(1))
views<-setNames(lapply(study_json$views,function(v){
 x<-do.call(rbind,lapply(v$values,function(row)vapply(row,function(value)if(is.null(value))NA_real_ else as.numeric(value),numeric(1))))
 colnames(x)<-unlist(v$features);rownames(x)<-unlist(v$sample_ids)
 x[match(meta$sample_id,rownames(x)),,drop=FALSE]
}),view_names)
study<-list(metadata=meta,views=views,levels=unlist(study_json$group_order),units=setNames(lapply(study_json$views,function(v)v$unit),view_names))
lab<-run_lab(study,max_missing=p$max_missing,model_features=p$model_features,
 feature_scaling=p$feature_scaling,feature_alignment="matched_genes",mofa_center=TRUE)
stopifnot(identical(colnames(lab$prepared$Proteomics$model),colnames(lab$prepared$RNA$model)))
dir.create("outputs",showWarnings=FALSE)
for(name in names(lab$prepared)){x<-lab$prepared[[name]]$model;write.csv(data.frame(sample_id=rownames(x),x,check.names=FALSE),paste0("outputs/",name,"_model_matrix.csv"),row.names=FALSE)}
write.csv(data.frame(gene_id=colnames(lab$prepared$Proteomics$model),protein_feature_id=colnames(lab$prepared$Proteomics$model),rna_feature_id=colnames(lab$prepared$RNA$model)),"outputs/gene_alignment.csv",row.names=FALSE)
print(plot_quality(lab));print(plot_gene_pair(lab));print(plot_feature_heatmap(lab))
if(p$method=="mofa") {
 mofa<-fit_lab_mofa(lab,factors=p$factors,iterations=300,scale_views=FALSE,runtime="managed",
  outfile="outputs/MOFA.hdf5")
 print(plot_integration(lab,mofa));print(plot_factor_contributions(mofa));print(plot_sample_factors(lab,mofa))
 net<-factor_network(lab,mofa,factor=1,top_per_view=6);print(plot_factor_network(net))
 annotations<-jsonlite::fromJSON("bee_annotations.json",simplifyVector=FALSE)
 ora<-factor_enrichment(lab,mofa,annotations,factor=1,view="Proteomics",catalog="GO_BP",top_n=20)
 print(plot_pathway_results(ora))
 saveRDS(list(lab=lab,mofa=mofa),"outputs/analysis.rds")
 export_publication(plot_integration(lab,mofa),"outputs/integration",width=10)
} else {
 # Six donors: start with PCA. To explore MOFA explicitly, set p$method <- "mofa" above.
 print(scatter_scores(lab$joint_pca$scores,lab,"Joint PCA","PC1","PC2"))
 saveRDS(list(lab=lab),"outputs/analysis.rds")
}
