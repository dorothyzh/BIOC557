# Run in RStudio with this extracted folder as the working directory.
# This downloads the original source files to your computer, not to the website.
# Use sources under their applicable access conditions; do not redistribute data.
for(pkg in c("readxl","jsonlite"))
  if(!requireNamespace(pkg,quietly=TRUE)) install.packages(pkg,repos="https://cloud.r-project.org")
source("prepare_AD.R")
dir.create("source_data",showWarnings=FALSE)
options(timeout=max(600,getOption("timeout")))
for(s in ad_sources) {
  destination<-file.path("source_data",s$file)
  if(!file.exists(destination)) download.file(s$url,destination,mode="wb",method="libcurl")
}
# Default: 87 Control + 110 Symptomatic AD donors from the published expression table.
prepare_ad(contrast=c("Normal","SAD"))
# To explore another contrast, run one of these instead:
# prepare_ad(contrast=c("Normal","AAD"))
# prepare_ad(contrast=c("AAD","SAD"))
# Load data/AD_study.json using the Alzheimer's brain card on the web lab.
