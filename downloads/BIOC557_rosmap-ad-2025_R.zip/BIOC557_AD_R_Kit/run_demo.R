# Prepare data first: source("start_AD.R").
# First MOFA2 installation: source("R/install_packages.R").
source("R/lab_core.R")
source("R/lab_plots.R")
source("R/lab_explore.R")
meta<-read.csv("data/metadata.csv",check.names=FALSE)
view_names<-c("Proteomics","Lipidomics")
views<-setNames(lapply(view_names,function(v){
  d<-read.csv(paste0("data/",v,".csv"),check.names=FALSE)
  stopifnot(!anyDuplicated(d$sample_id),setequal(d$sample_id,meta$sample_id))
  x<-as.matrix(d[match(meta$sample_id,d$sample_id),-1,drop=FALSE])
  storage.mode(x)<-"double";rownames(x)<-meta$sample_id;x
}),view_names)
study<-list(metadata=meta,views=views,levels=unique(meta$group))
lineage_colors<-setNames(c("#1a8191","#bd683c"),study$levels)
lab<-run_lab(study,model_features=100,feature_scaling="unit_variance",mofa_center=TRUE)
mofa<-fit_lab_mofa(lab,factors=3,runtime="managed")
print(plot_integration(lab,mofa))
print(plot_factor_contributions(mofa))
net<-factor_network(lab,mofa,factor=1,top_per_view=6)
print(plot_factor_network(net))
annotations<-jsonlite::fromJSON("human_gene_annotations.json",simplifyVector=FALSE)
ora<-factor_enrichment(lab,mofa,annotations,factor=1,view="Proteomics",catalog="GO_BP",top_n=20)
if(nrow(ora$rows)) print(plot_pathway_results(ora))
saveRDS(list(lab=lab,mofa=mofa),"outputs/AD_analysis.rds")
# Change factors=2, 4, 5 or 6 and rerun to compare the factor models.
# Feature scaling: "none", "unit_variance", "pareto"; mofa_center: TRUE/FALSE.
# To draw editable PDF and 600-dpi PNG:
# export_publication(plot_factor_contributions(mofa),"outputs/AD_factors")
