# BIOC557: prepare the 2025 ROSMAP protein + lipid teaching example in R.
# Individual-level data stay on your computer. Do not commit data/ or outputs/.
# Obtain source files only under the source study's applicable access conditions.

ad_sources <- list(
  protein=list(file='ROSMAP_source_data.xlsx',
    url='https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2Fs41467-025-64328-8/MediaObjects/41467_2025_64328_MOESM6_ESM.xlsx'),
  lipid=list(file='lipidomic_SERRF_AD phenotype.csv',
    url='https://raw.githubusercontent.com/lipidomicR/ROSMAP/main/lipidomic_SERRF_AD%20phenotype.csv')
)

prepare_ad <- function(source_dir='source_data', output_dir='data',
                       contrast=c('Normal','SAD'), max_features=1200) {
  for(pkg in c('readxl','jsonlite'))
    if(!requireNamespace(pkg,quietly=TRUE)) stop('Install ',pkg,': install.packages("',pkg,'")')
  if(length(contrast)!=2 || anyDuplicated(contrast) || !all(contrast %in% c('Normal','AAD','SAD')))
    stop('Choose two distinct source groups: Normal, AAD, SAD.')
  if(max_features<4 || max_features>5000) stop('Use 4-5000 features per view.')
  dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
  manifest <- jsonlite::fromJSON('source_manifest.json',simplifyVector=FALSE)
  for(key in names(ad_sources)) {
    path <- file.path(source_dir,ad_sources[[key]]$file)
    if(!file.exists(path)) stop('Missing ',path,'. See README.html for the original source links.')
    if(unname(tools::md5sum(path))!=manifest[[key]]$md5)
      stop('Source file differs from the verified release: ',path,'. Check the source version before continuing.')
  }
  p <- as.data.frame(readxl::read_excel(file.path(source_dir,ad_sources$protein$file),
                        sheet='Protein expression profile',na=c('NA',''),.name_repair='minimal'))
  lip <- read.csv(file.path(source_dir,ad_sources$lipid$file),check.names=FALSE,stringsAsFactors=FALSE)
  if(!identical(names(p)[1],'Participant_ID') || !identical(names(lip)[1:2],c('patient id','Class')))
    stop('Unexpected source columns.')
  raw_id <- trimws(lip[['patient id']])
  if(any(!grepl('^.*_(R[0-9]+)$',raw_id))) stop('Unexpected lipid sample ID format.')
  lipid_ids <- sub('^.*_(R[0-9]+)$','\\1',raw_id)
  protein_ids <- trimws(as.character(p[[1]]))
  if(anyDuplicated(lipid_ids) || anyDuplicated(protein_ids)) stop('Duplicate participant IDs.')
  # Class labels independently agree between the author's CSV and source workbook.
  labels <- as.data.frame(readxl::read_excel(file.path(source_dir,ad_sources$protein$file),
                         sheet='Total lipid class_Figure 2b-c',.name_repair='minimal'))
  label_id <- as.character(labels[[1]]); label_group <- as.character(labels$Class)
  label_group[label_group=='Control'] <- 'Normal'
  if(anyNA(match(label_id,lipid_ids)) || any(label_group!=lip$Class[match(label_id,lipid_ids)]))
    stop('Group labels disagree between the two published sources.')
  matched <- sort(intersect(protein_ids,lipid_ids))
  ids <- unlist(lapply(contrast,function(g) matched[lip$Class[match(matched,lipid_ids)]==g]),use.names=FALSE)
  groups_raw <- lip$Class[match(ids,lipid_ids)]
  group_names <- c(Normal='Control',AAD='Asymptomatic AD',SAD='Symptomatic AD')
  groups <- unname(group_names[groups_raw])
  if(any(table(groups)<3)) stop('Each comparison group needs at least three matched donors.')
  protein <- as.matrix(p[match(ids,protein_ids),-1,drop=FALSE]);storage.mode(protein)<-'double'
  source_names <- colnames(protein);genes <- sub('\\|.*$','',source_names)
  keep <- grepl('^[A-Za-z0-9_.-]+$',genes) & !genes %in% c('uncharacterized','NA','') &
          !duplicated(genes) & !duplicated(genes,fromLast=TRUE)
  protein <- protein[,keep,drop=FALSE];colnames(protein)<-genes[keep];rownames(protein)<-ids
  source_map <- setNames(as.list(source_names[keep]),genes[keep])
  # Protein values are already normalized, signed log-scale expression values.
  # Do not take another log, and do not interpret these as absolute concentrations.
  lipid <- as.matrix(lip[match(ids,lipid_ids),-(1:2),drop=FALSE]);storage.mode(lipid)<-'double'
  lipid[lipid<=0]<-NA_real_;lipid<-log2(lipid);rownames(lipid)<-ids
  make_view <- function(name,x,unit) {
    variance<-apply(x,2,var,na.rm=TRUE)
    keep<-colMeans(is.na(x))<=.5 & is.finite(variance) & variance>1e-12
    x<-x[,keep,drop=FALSE];ix<-order(-variance[keep],seq_len(sum(keep)))
    x<-x[,head(ix,max_features),drop=FALSE]
    list(name=name,sample_ids=ids,features=colnames(x),values=x,input_scale='transformed',unit=unit)
  }
  views<-list(make_view('Proteomics',protein,'Published normalized protein log-scale abundance'),
              make_view('Lipidomics',lipid,'log2 SERRF-normalized LC-MS peak area'))
  lipid_classes<-sub('\\(.*$','',sub('^[0-9]+_','',views[[2]]$features))
  metadata<-data.frame(sample_id=ids,group=groups,source_group=groups_raw)
  source<-list(papers=list(list(title='Integrative brain omics approach highlights sn-1 lysophosphatidylethanolamine in Alzheimer\u2019s dementia',
                journal='Nature Communications',year=2025,url='https://doi.org/10.1038/s41467-025-64328-8')),
    repository='https://www.synapse.org/Synapse:syn26452612',
    access='Individual-level human data must not be redistributed outside the AD Knowledge Portal. This local preparation does not grant data access or redistribution permission.',
    files=manifest,
    processing=c('Exact participant-ID inner join of the published protein expression sheet and author lipid CSV; never match rows by position.',
      'The expression table has 268 donors shared with the lipid CSV. The paper reports 266 for a different module-level integration subset; this is a new feature-level classroom analysis.',
      paste('Retain source groups',paste(contrast,collapse=' versus '),'only. No unprovided age, sex or pathology scores are inferred.'),
      'Protein: retain unique, unambiguous gene symbols before the pipe; preserve published signed log-scale expression and NA values, without another logarithm.',
      'Lipid: use author SERRF-normalized areas; nonpositive intensities become missing, then log2. No new imputation before MOFA or differential testing.',
      'Retain features observed in at least half the selected donors and with nonzero variance; keep at most 1200 per view ranked by variance, without using group labels. Browser filtering is separate.'))
  d<-list(title='Alzheimer\u2019s brain: proteins and lipids',sample_ids=ids,groups=groups,
    group_order=unname(group_names[contrast]),metadata=metadata,views=views,source=source,
    pairing_unit='Exact participant identity in published dorsolateral prefrontal cortex tables; different assays, not the same aliquot.',
    feature_classes=list(Lipidomics=setNames(as.list(lipid_classes),views[[2]]$features)),
    source_feature_map=list(Proteomics=source_map[views[[1]]$features]),
    teaching=list(id='rosmap-ad-2025',species='Homo sapiens',year=2025,default_factors=3,
      annotation_mode='human_protein_lipid',sample_label='matched brain donors',local_only=TRUE,
      description=paste(length(ids),'matched donors;',paste(unname(group_names[contrast]),collapse=' versus '),'. Protein and lipid measurements from the same participant identities.'),
      warning='A feature-level teaching reanalysis, not a reproduction of the paper\u2019s 266-person module model. Differences are unadjusted for clinical covariates. Lipid classes describe chemistry, not pathway activity. Data stay in this browser and in local R files; do not publish participant-level exports.'))
  jsonlite::write_json(d,file.path(output_dir,'AD_study.json'),auto_unbox=TRUE,na='null',digits=8,matrix='rowmajor')
  write.csv(metadata,file.path(output_dir,'metadata.csv'),row.names=FALSE)
  for(v in views)write.csv(data.frame(sample_id=ids,v$values,check.names=FALSE),file.path(output_dir,paste0(v$name,'.csv')),row.names=FALSE,na='')
  jsonlite::write_json(source,file.path(output_dir,'provenance.json'),auto_unbox=TRUE,pretty=TRUE)
  message('Prepared ',length(ids),' donors: ',paste(names(table(groups)),table(groups),collapse='; '),'. Load data/AD_study.json in the web lab.')
  invisible(d)
}
