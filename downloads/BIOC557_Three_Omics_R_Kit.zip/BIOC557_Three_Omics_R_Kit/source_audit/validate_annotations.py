from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent;root=R.parents[1]
a=json.loads((R/'annotations.json').read_text());study=json.loads((root/'data/study.json').read_text());genes=set().union(*(set(v['features']) for v in study['views'] if v['name'] in ['Proteomics','RNA']));met=set(next(v['features'] for v in study['views'] if v['name']=='Metabolomics'));mapping={r['feature_id']:r for r in a['metabolite_mapping']}
assert set(mapping)==met
checks=[]
for name,terms in a['catalogs'].items():
    allowed=met if name=='Metabolite_pathways' else genes
    assert len(set(t['id'] for t in terms))==len(terms)
    assert all(isinstance(t['members'],list) and t['members'] and set(t['members'])<=allowed and len(set(t['members']))==len(t['members']) for t in terms)
    checks.append(name+': unique termIDs and valid deduplicated supplied members')
for f,r in mapping.items():
    if r['status'] in ['ambiguous','unmapped']:assert not r['compound_id']
    if re.match(r'^C\d+:\d+ ',f) or '/' in f:assert not r['compound_id']
assert mapping['malate']['status']=='ambiguous'
assert mapping['glutathione reduced']['compound_id']=='C00051'
assert mapping['alpha-ketoglutarate']['compound_id']=='C00026'
assert mapping['NAD']['compound_id']=='C00003'
checks.append('Ambiguous lipids/isomer mixtures excluded; known compound and synonym checks passed')
links=set(tuple(s.split('\t')) for s in (R/'kegg_compound_pathways.txt').read_text().splitlines())
for t in a['catalogs']['Metabolite_pathways']:
    for member in t['members']:assert ('cpd:'+mapping[member]['compound_id'],'path:'+t['reference_id']) in links
checks.append('Every metabolite pathway edge independently checked against downloaded official KEGG links')
for f in json.loads((R/'download_manifest.json').read_text()):assert hashlib.sha256((R/f['local_file']).read_bytes()).hexdigest()==f['sha256']
checks.append('All downloaded primary source SHA256 hashes matched')
report={'passed':True,'checks':checks,'counts':a['provenance']['counts']}
(R/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
