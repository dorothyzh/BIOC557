"""Reproduce the label-free BIOC557 CCLE teaching subset from the recorded public source files.
Biological pairing unit: unique CCLE cell-line identity, not a common cell pellet/aliquot.
"""
from pathlib import Path
from urllib.request import Request,urlopen
import json,re,hashlib,warnings
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent
OUT=R/'prepared';OUT.mkdir(exist_ok=True)
SOURCES={
 'proteomics.csv.gz':'https://gygi.hms.harvard.edu/data/ccle/protein_quant_current_normalized.csv.gz',
 'rna.csv':'https://ndownloader.figshare.com/files/24613349',
 'sample_info.csv':'https://ndownloader.figshare.com/files/24613394',
 'metabolomics.csv':'https://data.broadinstitute.org/ccle/CCLE_metabolomics_20190502.csv'}
for name,url in SOURCES.items():
 if not (R/name).exists():
  with urlopen(Request(url,headers={'User-Agent':'BIOC557-data/1.0'}),timeout=180) as h,open(R/name,'wb') as out:
   while True:
    b=h.read(1024*1024)
    if not b:break
    out.write(b)
protein=pd.read_csv(R/'proteomics.csv.gz')
meta=pd.read_csv(R/'sample_info.csv')
metab=pd.read_csv(R/'metabolomics.csv')
rna_ids=set(pd.read_csv(R/'rna.csv',usecols=[0]).iloc[:,0])
pcs=[c for c in protein if re.search(r'_TenPx\d+$',c)]
pnames=[re.sub(r'_TenPx\d+$','',c) for c in pcs]
lookup=meta.dropna(subset=['CCLE_Name']).set_index('CCLE_Name')
assert not lookup.index.duplicated().any()
assert not metab.DepMap_ID.duplicated().any()
matched=[]
for c,name in zip(pcs,pnames):
 if pnames.count(name)!=1 or name not in lookup.index:continue
 a=lookup.loc[name];id=a.DepMap_ID
 if id in set(metab.DepMap_ID) and id in rna_ids and a.lineage in ['breast','skin']:
  matched.append({'sample_id':id,'group':str(a.lineage).title(),'cell_line':name,'lineage':a.lineage,'primary_disease':a.primary_disease,'tmt_batch':c.rsplit('_',1)[-1],'protein_column':c})
matched=sorted(matched,key=lambda m:(['Breast','Skin'].index(m['group']),m['cell_line']))
md=pd.DataFrame(matched);ids=md.sample_id.tolist()
assert len(ids)==61 and len(set(ids))==61
print('Cohort',md.group.value_counts().to_dict(),flush=True)
# Parse the large RNA source in row chunks, keeping only these 61 cell lines.
rna_chunks=[]
for chunk in pd.read_csv(R/'rna.csv',chunksize=30):
 rows=chunk[chunk.iloc[:,0].isin(ids)]
 if len(rows):rna_chunks.append(rows)
rna=pd.concat(rna_chunks).set_index('Unnamed: 0').loc[ids]
# Keep unique single-symbol proteins. Ambiguous multi-gene or duplicated symbols excluded.
pg=protein.Gene_Symbol.fillna('').astype(str)
valid_gene=pg.str.match(r'^[A-Za-z0-9][A-Za-z0-9_.-]*$') & ~pg.duplicated(keep=False)
px=protein.loc[valid_gene,md.protein_column.tolist()].T
px.columns=pg[valid_gene];px.index=ids
with warnings.catch_warnings():
 warnings.simplefilter('ignore');pvar=px.var(axis=0,skipna=True,ddof=1)
# Pool selection does not use lineage labels; source gaps preserved. Missingness <=50%.
pkeep=(px.isna().mean(axis=0)<=.5)&np.isfinite(pvar)&(pvar>1e-12)
pchosen=pvar[pkeep].sort_values(ascending=False,kind='stable').index[:1200]
px=px.loc[:,pchosen]
# Restrict RNA to unique gene symbols, then select 1200 high-variance genes without labels.
rna_symbols=[c.split(' (')[0] for c in rna.columns]
sc=pd.Series(rna_symbols)
unique_rna=~sc.duplicated(keep=False)
rx=rna.loc[:,unique_rna.to_numpy()].copy();rx.columns=sc[unique_rna].tolist()
rv=rx.var(axis=0,ddof=1)
rchosen=rv[np.isfinite(rv)&(rv>1e-12)].sort_values(ascending=False,kind='stable').index[:1200]
rx=rx.loc[:,rchosen]
# Retain all 225 source metabolite features, including author-imputed values.
mx=metab.set_index('DepMap_ID').loc[ids].drop(columns='CCLE_ID')
assert mx.shape[1]==225
# 6 decimal places retain classroom precision and keep browser payload modest.
frames={'Proteomics':px.round(6),'RNA':rx.round(6),'Metabolomics':mx.round(6)}
units={'Proteomics':'Normalized log₂ protein ratio','RNA':'log₂(TPM + 1)','Metabolomics':'Cleaned log₁₀ metabolite abundance (source imputed)'}
for name,x in frames.items():
 x.rename_axis('sample_id').to_csv(OUT/(name.lower()+'.csv'),index=True)
md.drop(columns='protein_column').to_csv(OUT/'metadata.csv',index=False)
ann=[]
pinfo=protein.loc[valid_gene].set_index('Gene_Symbol')
rna_source={sym:col for sym,col,keep in zip(rna_symbols,rna.columns,unique_rna) if keep}
for name,x in frames.items():
 for f in x.columns:
  if name=='Proteomics':src=str(pinfo.loc[f,'Protein_Id']);desc=str(pinfo.loc[f,'Description']);gene=f
  elif name=='RNA':src=rna_source[f];desc=f;gene=f
  else:src=f;desc=f;gene=''
  ann.append({'view':name,'feature_id':f,'feature_name':desc,'source_id':src,'scale':units[name],'gene_symbol':gene})
pd.DataFrame(ann).to_csv(OUT/'annotations.csv',index=False)
pairs=sorted(set(px.columns)&set(rx.columns))
# If independently selected views share few genes, keep valid wider source pairs separately available.
pair_rows=[{'gene_symbol':g,'protein_feature_id':g,'rna_feature_id':g} for g in pairs]
pd.DataFrame(pair_rows).to_csv(OUT/'shared_gene_pairs.csv',index=False)
files=[]
for fn,url in SOURCES.items():
 p=R/fn;files.append({'local_file':fn,'url':url,'sha256':hashlib.file_digest(open(p,'rb'),'sha256').hexdigest(),'bytes':p.stat().st_size})
provenance={
 'dataset_id':'ccle_three_view_breast_skin_61',
 'title':'CCLE three-view teaching subset: breast and skin cancer cell lines',
 'pairing_unit':'Unique CCLE/DepMap cell-line identity across public assays; these profiles are not claimed to be from the same biological aliquot or culture batch.',
 'cohort':'All unambiguously matched breast (28) and skin (33) lines with RNA, TMT mass-spectrometry proteomics and LC-MS metabolomics available; no random sample downsampling.',
 'sources':files,
 'papers':[
 {'authors':'Nusinow et al.','title':'Quantitative Proteomics of the Cancer Cell Line Encyclopedia','journal':'Cell','year':2020,'doi':'10.1016/j.cell.2019.12.023','url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC7339254/'},
 {'authors':'Ghandi et al.','title':'Next-generation characterization of the Cancer Cell Line Encyclopedia','journal':'Nature','year':2019,'doi':'10.1038/s41586-019-1186-3','url':'https://doi.org/10.1038/s41586-019-1186-3'},
 {'authors':'Li et al.','title':'The landscape of cancer cell line metabolism','journal':'Nature Medicine','year':2019,'doi':'10.1038/s41591-019-0404-8','url':'https://doi.org/10.1038/s41591-019-0404-8'}],
 'rna_release':{'name':'DepMap public_20q3','article_id':12931238,'url':'https://api.figshare.com/v2/articles/12931238','note':'File IDs24613349 and24613394 verified in this article through the official Figshare API.'},
 'processing':[
 'Map proteomic columns to CCLE_Name after removing the _TenPxXX suffix. Exclude cell lines with multiple proteomic sample columns and require exact unique CCLE_Name-to-DepMap_ID metadata mapping.',
 'Inner join all three views by DepMap_ID, then retain all matched breast and skin lines. No nearest-name or fuzzy matching.',
 'Protein teaching pool: unique single gene symbols only; exclude features >50% missing or zero variance; rank by variance over all61 lines without group labels, retain1200.',
 'RNA teaching pool: unique gene symbols only; remove zero-variance features; rank by variance over all61 lines without group labels, retain1200 independently of proteins.',
 'Retain all225 public metabolite columns. This source was already cleaned, batch-corrected and imputed by its authors; zero observed gaps do not imply no original missingness.',
 'Preserve upstream transformed scales. No log transform, z-scoring, new imputation or normalization during extraction. Round exported values to6decimal places; source files remain available for audit.'
 ],
 'view_scales':units,
 'sample_counts':md.group.value_counts().to_dict(),
 'features':{n:x.shape[1] for n,x in frames.items()},
 'missing_fraction':{n:float(x.isna().mean().mean()) for n,x in frames.items()},
 'shared_selected_rna_protein_genes':len(pairs),
 'limitations':['Different assays can use different cell stocks, collection times and processing batches; cell-line identity is the unit of integration, not a paired common aliquot.', 'Tissue-lineage comparisons are descriptive exploratory examples, not a clinical classification experiment.', 'Protein and RNA high-variance teaching pools were selected independently before classroom filtering; these are reduced, data-selected views rather than whole-omics matrices.', 'Metabolite source values were already imputed upstream, so original missingness cannot be reconstructed from the supplied file.']}
(OUT/'provenance.json').write_text(json.dumps(provenance,indent=2,allow_nan=False))
views=[]
for name,x in frames.items():
 values=x.astype(object).where(pd.notna(x),None).values.tolist()
 views.append({'name':name,'sample_ids':ids,'features':x.columns.tolist(),'values':values,'unit':units[name],'input_scale':'transformed'})
study={'title':provenance['title'],'sample_ids':ids,'groups':md.group.tolist(),'group_order':['Breast','Skin'],'metadata':md.drop(columns='protein_column').to_dict(orient='records'),'source':provenance,'views':views,'shared_gene_pairs':pair_rows,'pairing_unit':provenance['pairing_unit']}
(OUT/'study.json').write_text(json.dumps(study,separators=(',',':'),allow_nan=False))
print('Features',provenance['features'],'missing',provenance['missing_fraction'],'shared genes',len(pairs),'study bytes',(OUT/'study.json').stat().st_size,flush=True)
