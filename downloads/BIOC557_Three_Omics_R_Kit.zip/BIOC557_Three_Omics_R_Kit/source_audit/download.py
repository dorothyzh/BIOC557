from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
urls={
'reactome_current.gmt.zip':'https://reactome.org/download/current/ReactomePathways.gmt.zip',
'kegg_compounds.txt':'https://rest.kegg.jp/list/compound',
'kegg_human_pathways.txt':'https://rest.kegg.jp/list/pathway/hsa',
'kegg_compound_pathways.txt':'https://rest.kegg.jp/link/pathway/compound'}
def fetch(item):
 n,u=item
 with urlopen(Request(u,headers={'User-Agent':'BIOC557-annotations/1.0'}),timeout=90) as h:b=h.read()
 (R/n).write_bytes(b);return {'local_file':n,'url':u,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with ThreadPoolExecutor(max_workers=4) as p:src=list(p.map(fetch,urls.items()))
(R/'download_manifest.json').write_text(json.dumps(src,indent=2))
print(src)
with zipfile.ZipFile(R/'reactome_current.gmt.zip') as z:
 for name in z.namelist():
  text=z.read(name).decode();(R/'reactome_current.gmt').write_text(text);print('\n'.join(text.splitlines()[:2])[:1200])
