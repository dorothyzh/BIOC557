# Offline GO and pathway annotations for BIOC557

The files in this directory support conditional, exploratory over-representation analysis of factor-loading feature lists. No enrichment-dependent terms were selected when building the catalogs.

## Files and schema

- `annotations.json`: `catalogs.GO_BP`, `catalogs.Reactome`, `catalogs.Metabolite_pathways`, `metabolite_mapping`, and full `provenance`.
- Each catalog is an array of `{id, name, members, source_url}` objects. Metabolite pathway entries additionally contain `reference_id` (KEGG `map` identifier). Members are the original supplied feature IDs: gene symbols for proteins/RNA, original metabolite labels for metabolites.
- `metabolite_mapping.csv`: all225 metabolite features, strict mapping status, compound ID, matched name, evidence URL, exclusion reason, lipid chemical class, and pathway-count coverage.
- `provenance.json`: source URLs, versions, extraction choices, SHA-256 source hashes, and background guidance.
- `extract_gene_ontology.R`, `download.py`, `build_annotations.py`: reproducible extraction/build scripts. Scripts use absolute local project paths and can be edited for another checkout.

## Source snapshots

**GO Biological Process:** installed Bioconductor `org.Hs.eg.db3.19.1` and `GO.db3.19.1`, with GO ontology source date2024-01-17 and Entrez-GO source date2024-Mar12. This is an explicitly versioned historical snapshot, not a claim to current GO annotation. GOALL propagates memberships through ancestors; all available evidence types are included. Retain all9134 BP terms overlapping at least one of the1878 supplied protein/RNA gene symbols.

**Reactome:** directly published official human GMT, release98, last-modified2026-10-19. Retain all1786 R-HSA pathways with at least one supplied gene member. Source: https://reactome.org/download/current/ReactomePathways.gmt.zip . Database version checked with https://reactome.org/ContentService/data/database/version .

**Metabolite pathways:** official KEGG compound names/synonyms, official compound-to-reference-pathway links, and human pathway-name list, fetched2026-11-11.153 reference maps with human counterparts remain after excluding broad map011xx/map012xx overview maps. These include disease/signaling maps as well as metabolism; label the catalog **KEGG pathways (reference maps)**. For a strictly metabolic subset, select numeric human pathway IDs below01100. Reference-map membership is not a reconstruction of human-specific reactions.

## Metabolite identity coverage

225 supplied features:84 unique exact-name matches,3 explicitly curated synonyms,113 ambiguous labels and25 unmapped.66 features have at least one usable pathway membership. Three curated synonyms are alpha-ketoglutarate→C00026 (acid/base spelling), glutathione oxidized→C00127, and glutathione reduced→C00051 (word order and explicit redox state); all are supported by KEGG's own synonym list.

Normalization changes punctuation/spacing only and does not strip L/D/R/S stereochemical labels. Where a name hits multiple KEGG entries, it remains ambiguous. Unspecified amino acids are not silently converted to L-amino acid entries. A generic exact-name entry may have no KEGG pathway link; this is preserved. Name mapping is not new analytical confirmation of an experimental metabolite identity.

Lipid sum-composition labels such as C56:5 TAG, isomer mixtures such as DHAP/glyceraldehyde3P, and generic hexose labels are excluded from compound ORA. The lipid class field can support a chemical-class visualization but is not molecular pathway evidence. In particular, unmapped lipids must not be silently treated as absent molecules or forced to specific KEGG structures.

## Correct statistical use

For a selected factor and molecular view:

1. Choose top-loading features by the stated absolute/positive/negative rule.
2. Set background to actual model-view features intersected with the selected catalog's annotated-feature union; deduplicate identifiers.
3. Intersect the query with that same background. Report both mapped query count and mapped background count, plus total selected features.
4. Test all eligible catalog terms with one-tailed hypergeometric/Fisher over-representation. Define any minimum/maximum background-overlap filters before inspecting p values.
5. Apply BH across all tested terms within the factor/view/catalog/sign selection, including terms with p=1; do not correct only the displayed hits.
6. Display term IDs, overlap members, counts, p/q values and FDR status. Zero mapped query or zero eligible terms should produce an explanatory empty state.

Catalogs are restricted to this supplied teaching pool. Uploaded features outside the pool lack local annotation and need a new source-backed annotation build. Repeating many factor counts, signs, thresholds and preprocessing choices makes these visualizations exploratory; a displayed q value does not account for every interactive choice.

## Baseline demo coverage

At the current3-factor100-features/view model, mapped metabolite background is29/100; top20 absolute features map6,1,4 features for factors1,2,3. These small lists do not show strong metabolite enrichment. Show ranked candidates with nonsignificant status rather than inventing a positive result. RNA examples include epithelium development and pigmentation/melanin process terms; term ranks and significance change with the exact selection/background rules.
