from pathlib import Path
from collections import defaultdict,Counter
import csv,json,re,hashlib,datetime
R=Path(__file__).resolve().parent;ROOT=R.parents[1]
study=json.loads((ROOT/'data/study.json').read_text());genes=set().union(*(set(v['features']) for v in study['views'] if v['name'] in ['Proteomics','RNA']));metabolites=next(v['features'] for v in study['views'] if v['name']=='Metabolomics')
# Reactome's directly published human GMT, fetched without inferred pathways.
reactome=[]
for line in (R/'reactome_current.gmt').read_text().splitlines():
    fields=line.split('\t');name,pid,*members=fields
    if not pid.startswith('R-HSA-'):continue
    members=sorted(set(members)&genes)
    if members:reactome.append({'id':pid,'name':name,'members':members,'source_url':'https://reactome.org/content/detail/'+pid})
go=json.loads((R/'go_bp.json').read_text())
for term in go['terms']:
    if isinstance(term['members'],str):term['members']=[term['members']]
    term['members']=sorted(set(term['members']))
    if not term.get('name'):term['name']=term['id']
# Name normalization changes punctuation/spacing only. It never strips L/D/R/S labels.
def norm(s):return re.sub(r'[^a-z0-9]','',s.lower())
idx=defaultdict(list);compound_names={}
for line in (R/'kegg_compounds.txt').read_text().splitlines():
    cid,names=line.split('\t',1);compound_names[cid]=names.split('; ')
    for name in compound_names[cid]:idx[norm(name)].append((cid,name))
# Acid/base and word-order equivalents validated against KEGG's own names.
aliases={
 'alpha-ketoglutarate':('C00026','alpha-Ketoglutaric acid','Acid/base spelling of the KEGG synonym alpha-Ketoglutaric acid.'),
 'glutathione oxidized':('C00127','Oxidized glutathione','Word order of the explicit redox-state KEGG synonym.'),
 'glutathione reduced':('C00051','Reduced glutathione','Word order of the explicit redox-state KEGG synonym.')}
for feature,(cid,syn,reason) in aliases.items():assert syn in compound_names[cid]
mapping=[]
for feature in metabolites:
    row={'feature_id':feature,'status':'unmapped','compound_id':'','matched_name':'','source_url':'','reason':'No strict unambiguous KEGG compound name match.','chemical_class':'small_molecule','candidate_compound_ids':''}
    lipid=re.match(r'^C\d+:\d+ (LPC|LPE|PC|SM|DAG|CE|TAG)(?:-[AB])?$',feature)
    if lipid:
        row.update(status='ambiguous',reason='Lipid sum-composition/class label; molecular species and/or acyl-chain positions are unresolved. Excluded from compound-pathway ORA.',chemical_class=lipid.group(1))
    elif '/' in feature or feature.startswith('hexoses '):
        row.update(status='ambiguous',reason='Source label explicitly groups isomers/compounds or a chemical class. Excluded from compound-pathway ORA.',chemical_class='unresolved_mixture')
    else:
        matches=idx.get(norm(feature),[]);unique=sorted(set(c for c,n in matches))
        if len(unique)==1:
            cid=unique[0];syn=next(n for c,n in matches if c==cid)
            row.update(status='exact_name',compound_id=cid,matched_name=syn,source_url='https://www.kegg.jp/entry/'+cid,reason='One KEGG compound entry matches the normalized source feature name; no stereochemistry was inferred.')
        elif len(unique)>1:
            row.update(status='ambiguous',candidate_compound_ids=';'.join(unique),reason='Name matches more than one KEGG compound entry (including possible stereoisomers). Excluded from compound-pathway ORA.')
        elif feature in aliases:
            cid,syn,reason=aliases[feature];row.update(status='curated_synonym',compound_id=cid,matched_name=syn,source_url='https://www.kegg.jp/entry/'+cid,reason=reason)
    mapping.append(row)
# Reference compound links, restricted to maps that have a named human counterpart.
human={}
for line in (R/'kegg_human_pathways.txt').read_text().splitlines():
    pid,name=line.split('\t',1);pid=pid.removeprefix('path:');human['map'+pid.removeprefix('hsa')]=(pid,name.removesuffix(' - Homo sapiens (human)'))
cpd_paths=defaultdict(set)
for line in (R/'kegg_compound_pathways.txt').read_text().splitlines():
    c,p=line.split('\t');p=p.removeprefix('path:')
    if p in human:cpd_paths[c.removeprefix('cpd:')].add(p)
paths=defaultdict(set)
for row in mapping:
    hits=cpd_paths.get(row['compound_id'],set())
    # Exclude organism-wide overview maps: their huge overlap is uninformative for classroom ORA.
    hits={p for p in hits if not p.startswith('map011') and not p.startswith('map012')}
    row['pathway_count']=len(hits)
    for pid in hits:paths[pid].add(row['feature_id'])
metapaths=[{'id':human[p][0],'reference_id':p,'name':human[p][1],'members':sorted(m),'source_url':'https://www.kegg.jp/pathway/'+human[p][0]} for p,m in sorted(paths.items())]
provenance={'prepared_date':'2026-11-11','annotation_scope':'Offline catalogs restricted to gene/feature IDs in the supplied CCLE three-view teaching pools. Retain every term having at least one supplied member; no enrichment-dependent term selection.',
'gene_ontology':go['provenance'],'reactome':{'source':'Official Reactome current human GMT','download_url':'https://reactome.org/download/current/ReactomePathways.gmt.zip','snapshot':'Reactome release98; GMT Last-Modified2026-10-19; fetched2026-11-11','release_version':98,'version_api':'https://reactome.org/ContentService/data/database/version','processing':'Human R-HSA pathways only; retain gene-symbol members overlapping the union of supplied protein/RNA teaching pools.'},
'kegg':{'name_matching':'Strict normalized source-name to KEGG synonym matching, plus3 explicit curated acid/base or word-order synonyms. Normalization does not drop L/D/R/S labels. Multiple compound matches, isomer mixtures and sum-composition lipids are excluded. Names alone are not a new analytical identity confirmation.',
'pathway_membership':'Official compound→reference pathway links, restricted to maps with human pathway counterparts. This is reference-map membership, not a reconstruction of human-specific reactions. Exclude map011xx/map012xx broad overview maps.',
'limitations':'Many aminoacid source names lack stereochemistry; matching generic KEGG entries may have no pathway link. They are not silently converted into L-amino acids. Unknown or ambiguous IDs must not be treated as absent metabolites.'},
'background_guidance':'For each view and run, intersect the actual model-feature IDs with the union of the selected catalog memberships. Query is top-loading features intersect that same background; deduplicate IDs. Test all eligible terms, then BH-adjust within that view/catalog/factor/sign selection. Report measured/mapped background and query counts.',
'downloads':json.loads((R/'download_manifest.json').read_text()),
'counts':{'supplied_gene_union':len(genes),'GO_BP_terms':len(go['terms']),'Reactome_terms':len(reactome),'metabolite_pathway_terms':len(metapaths),'metabolite_mapping_status':dict(Counter(r['status'] for r in mapping)),'metabolites_with_pathway_membership':sum(r['pathway_count']>0 for r in mapping)},
'primary_documentation':['https://geneontology.org/docs/go-annotations/','https://bioconductor.org/packages/org.Hs.eg.db/','https://reactome.org/download-data/','https://www.genome.jp/kegg/rest/keggapi.html']}
# Package file hashes ensure the local GO snapshot is exactly reproducible.
for filename in ['go_bp.json','reactome_current.gmt']:
    b=(R/filename).read_bytes();provenance['downloads'].append({'local_file':filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'url':'Bioconductor org.Hs.eg.db/GO.db3.19.1 local installed snapshot' if filename=='go_bp.json' else 'https://reactome.org/download/current/ReactomePathways.gmt.zip'})
result={'schema_version':'1.0','catalogs':{'GO_BP':go['terms'],'Reactome':reactome,'Metabolite_pathways':metapaths},'metabolite_mapping':mapping,'provenance':provenance}
(R/'annotations.json').write_text(json.dumps(result,separators=(',',':'),ensure_ascii=False));(R/'provenance.json').write_text(json.dumps(provenance,indent=2,ensure_ascii=False))
with (R/'metabolite_mapping.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(mapping[0]));w.writeheader();w.writerows(mapping)
print(json.dumps(provenance['counts'],indent=2));print('JSON bytes', (R/'annotations.json').stat().st_size)
