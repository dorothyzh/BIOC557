# BIOC557 · CCLE three-view teaching subset

The integration unit is a **cell-line identity**, not a common tissue specimen, culture batch or aliquot. The same CCLE/DepMap models are linked across RNA sequencing, TMT mass-spectrometry proteomics and LC–MS metabolomics. No synthetic RNA or unrelated patient cohort was added.

The subset contains all **61 unambiguously matched breast and skin lines**: **28 breast**, **33 skin**. Groups are tissue-lineage labels for an exploratory classroom comparison. They are not clinical outcomes. Source assays may use different cell stocks, culture conditions and collection times.

## Source studies

- Nusinow et al. **Quantitative Proteomics of the Cancer Cell Line Encyclopedia.** *Cell*, 2020. DOI: [10.1016/j.cell.2019.12.023](https://doi.org/10.1016/j.cell.2019.12.023). Source: [Gygi Lab normalized proteomic matrix](https://gygi.hms.harvard.edu/data/ccle/protein_quant_current_normalized.csv.gz). The author method logs TMT measurements, ratios each sample to its bridge, and centers protein quantities within each multiplex. Missing measurements remain missing.
- Ghandi et al. **Next-generation characterization of the Cancer Cell Line Encyclopedia.** *Nature*, 2019. DOI: [10.1038/s41586-019-1186-3](https://doi.org/10.1038/s41586-019-1186-3). The downloaded RNA and cell-line annotation files are from **DepMap public_20q3**, [Figshare DOI 10.6084/m9.figshare.12931238.v1](https://doi.org/10.6084/m9.figshare.12931238.v1). File IDs 24613349 (`CCLE_expression_full.csv`) and 24613394 (`sample_info.csv`) were verified against the official Figshare article API.
- Li et al. **The landscape of cancer cell line metabolism.** *Nature Medicine*, 2019. DOI: [10.1038/s41591-019-0404-8](https://doi.org/10.1038/s41591-019-0404-8). Source: [Broad Institute CCLE metabolite matrix](https://data.broadinstitute.org/ccle/CCLE_metabolomics_20190502.csv). This is the publicly distributed **clean, imputed** matrix. Source imputation has already occurred; the original missingness cannot be recovered from this file.

## Exact matching and selection

1. Strip only the final `_TenPxXX` suffix from each proteomic sample column, then match the remaining name exactly to `CCLE_Name` in the source metadata.
2. Exclude cell-line identities with more than one proteomic sample column. Require unique metadata mapping to `DepMap_ID`.
3. Inner-join the protein, RNA and metabolite profiles by `DepMap_ID`. There are 367 unique cell-line identities in the total three-view overlap. Retain every matched breast or skin model, giving 61 lines. No fuzzy-name match or random downsampling is used.
4. For the protein teaching pool, require an unambiguous unique single gene symbol, nonzero variance, and no more than 50% missingness. Rank variance across the 61 lines **without group labels**, and retain 1,200 features. The later classroom missingness filter is a separate step.
5. For RNA, require unique gene symbols and nonzero variance; independently retain the 1,200 most variable genes across the same 61 lines, without group labels. Keep all 225 metabolite features.
6. Preserve transformed source values and missing protein entries. Extraction performs no new logarithm, normalization, imputation or z-scoring. Exports are rounded to six decimal places. The raw downloads and hashes support an audit of that rounding.

## Input scales and files

| View | Teaching features | Supplied scale | Observed missing fraction |
|---|---:|---|---:|
| Proteomics | 1,200 | Normalized log₂ relative protein abundance | 15.1626% |
| RNA | 1,200 | log₂(TPM + 1) | 0% |
| Metabolomics | 225 | Cleaned log₁₀ abundance, author-imputed | 0% |

Use **no additional log transform** for these three inputs. Each molecular view can then be centered and z-scored as part of model preparation. Different log bases are valid after within-feature scaling; raw effect sizes should retain their own view units.

`metadata.csv` includes sample ID, display cell-line name, group, tissue lineage, primary disease and the protein TMT batch. `annotations.csv` preserves source identifiers and descriptive names. `shared_gene_pairs.csv` maps **522 gene symbols** present in both independently selected RNA and protein pools; `study.json` embeds that mapping. The complete browser input is approximately 1.48 MB.

`provenance.json` records source URLs, SHA-256 hashes, scales and extraction steps. The reproducible extraction script is `../extract_ccle.py`; independent calculation/value checks are in `../validate_ccle.py` and `../validation.json`.
