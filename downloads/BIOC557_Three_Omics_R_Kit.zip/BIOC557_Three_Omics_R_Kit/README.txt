BIOC557: CCLE: protein, RNA and metabolites

1. Install R and RStudio Desktop once.
2. Extract this entire ZIP. Double-click BIOC557.Rproj.
3. Open START_HERE.R and click Source.

Missing packages install automatically on the first run. Keep RStudio open.
The finished report is BIOC557_Default_Lab.html. Figures and tables are in outputs/.
For later runs, open BIOC557_Default_Lab.Rmd and click Knit.
All demo data are included; you do not need to edit paths or parameters.
The default is MOFA with 5 factors, Pareto scaling and 100 features per view.
