# BIOC557 · Protein + RNA + metabolite integration

课堂网页：https://dorothyzh.github.io/BIOC557

新版默认是三组学 MOFA。学生可以全程点击网页，或在 RStudio 使用 R 教学包。学生不需要编写 Python。

## 学生使用 R

1. 解压 `BIOC557_Three_Omics_R_Kit.zip`，把 RStudio 工作目录设为解压后的 kit 根目录。
2. 在 R 运行 `source('R/install_packages.R')`（首次安装）。建议 R >=4.3、reticulate >=1.41。MOFA2 通过 Bioconductor 安装。
3. 打开 `BIOC557_Three_Omics_Lab.Rmd`，逐格执行或 Knit；也可运行 `source('R/01_run_lab.R')`。
4. 默认由 R 的 `reticulate::py_require()` 自动准备固定版本的 MOFA 计算依赖。代码、参数和绘图操作均为 R。首次运行要联网下载环境，建议课前完成。高级兼容模式可选 `runtime='basilisk'` 或已有环境 `runtime='existing'`。
5. `reference/BIOC557_Three_Omics_R_Example.html` 是完整执行的示例；`reference/figures/` 包含高清 PNG/PDF；`reference/BIOC557_MOFA.hdf5` 是已拟合的模型。
6. 网页导出的 ZIP 附 R replay 脚本、当前已经处理好的模型矩阵及 R helper。用 `source('analysis_in_R.R')` 可重新拟合这些实际输入；不用再次 log、缩放或过滤导出矩阵。

如用 UBC Jupyter Open，请用个人 CWL 登录 https://open.jupyter.ubc.ca，选择 R kernel，上传/解压 R kit，在 R 中运行上述脚本。R Markdown Knit 在 RStudio 中最方便。UBC 远端上传、安装及运行尚未由本次工作验证。

## 数据与真实配对范围

61个 CCLE/DepMap 细胞系：28 Breast、33 Skin；1,200 蛋白特征 +1,200 RNA 特征 +225 代谢特征；另有522个 RNA–蛋白共同基因 ID 对应。全部按严格唯一细胞系 ID 交集连接，不做模糊匹配。匹配的是相同细胞系模型，来自不同公开实验；不表示同一管样本或同一培养批次。

- 蛋白：归一化 log2 比值；原始缺失约15.16%。
- RNA：log2(TPM+1)，TPM为transcripts per million。
- 代谢物：作者清洗、批次校正和填补后的 log10 丰度。表内0缺失不代表原实验无缺失。

蛋白与RNA各自按全61个细胞系的方差选择1,200个教学特征，不使用组别标签；全部225个代谢物保留。课堂默认30%缺失阈值后，919/1200/225特征保留，模型每层最多100个高变特征。差异分析使用全部保留特征，Welch检验只使用观测值，BH在每层内校正。MOFA保留剩余缺失；PCA和距离使用特征中位数填补。推荐变换尊重每层已发表尺度，不再次取log。组间差异不是统一的log2 fold change；请看每层单位。

来源：Nusinow et al., Cell 2020, DOI10.1016/j.cell.2019.12.023；Ghandi et al., Nature 2019, DOI10.1038/s41586-019-1186-3；Li et al., Nature Medicine 2019, DOI10.1038/s41591-019-0404-8。RNA/metadata实际release为DepMap public_20q3。源URL、哈希、筛选和配对方法见 `data/provenance.json` 与 `source_audit/README_Sources.md`。

## 图和课堂练习

网页新增可切换因子的三层贡献气泡图、三组学距离一致性图、每个细胞系的因子热图、RNA–蛋白共同基因散点图（EPCAM、VIM、EGFR、ERBB2等），以及每个因子的高权重特征。R示例还包含三层特征热图、质控图及高清可导出的图。可以用代谢物占主要贡献的因子讲解单层与跨层信息。

建议45–60分钟：配对与尺度10分钟；质控和单层分析15分钟；MOFA与贡献图15分钟；基因例子及错误配对实验15分钟。教师要点在 `docs/Instructor_Notes.md`。

## 多人独立使用

公开网页提供静态文件；每个页面启动独立的 Web Worker / Python运行环境。参数、上传表格和计算结果只保存在该页面的内存中，不写入共享账户或数据库。导出文件名有独立 workspace ID，避免不同学生的结果混淆。计算期间锁定数据和参数控件，防止一次运行中途换数据造成混用。

本地验证包含10个独立浏览器worker同时拟合真实三层MOFA、不同seed与每层100/200特征，并验证每条返回的参数、61个ID、三层维度与61×3 scores。另核对两个页面不同参数和不同workspace结果互不改变。这是本机环境中的并发/隔离验证，不是10台真实学生电脑或UBC校园Wi-Fi的现场压测。首次访问需下载科学计算库，建议全班课前打开一次；当前页面刷新会清空未导出的结果。

## IP服务器版（可选，教师部署）

完整包包含同样的网页和可选Python API（学生端仍使用网页或R）。Python3.12机器运行 `./start-classroom.sh`，再访问 `http://服务器IP:8000`；有Docker时可用 `docker compose up --build -d`。没有购买或创建新的云服务器/公网IP。2CPU/4GB、2分析进程、10个排队位是起始配置，不是云端容量保证。公网使用现有机构的HTTPS与访问管理；只用于公开教学数据。

网页默认在学生自己的浏览器计算；IP服务会提供可选课堂后端，用户可切换回独立浏览器。后端请求隔离，服务不持久保存上传数据。Docker镜像未在本机构建。

## 实施说明

网页底层使用mofapy2 0.7.5 / Pyodide，不要求学生写Python；R包MOFA2也调用同一MOFA计算核心，这是官方R接口的正常设计。R和浏览器可能有因子次序/符号差异；预处理、单层统计及输入已核对。数据配对跨实验、原始代谢物填补、细胞系谱系与批次都适合在解释时讨论；共享因子本身不代表因果联系。

## 新增模型实验、网络和功能注释

- 因子数可选K=2–6；可实际重拟合K2/3/5等组合，显示每层总重建R²，并以分数的绝对Spearman相关和一对一匹配追踪参考模式。训练重建不是预测表现，也不据此宣布最佳K。
- 特征缩放分为unit variance（除以SD）、Pareto（除以√SD）和none。MOFA center针对全61个细胞系的每个特征均值，不分开中心化Breast/Skin。关闭center时保留均值偏移；整层view scaling再对一个完整view除以一个全局SD。
- 关闭center时，重建的零参照包含均值水平，和中心化方差不是同一分母。总R²从所有因子一起重建计算，不把逐因子R²相加。计算只使用实际MOFA输入的观测位置；构建模型前保存缺失掩码。
- 每个因子都有蛋白、RNA和代谢物三份独立的前8特征榜单，展示较弱的层而不人为增加其贡献。
- Network explorer支持“因子权重链接”和“跨组学观测相关”两种图。相关边需要至少10个完整观测对，按阈值筛选并最多显示100条。点击节点可查看其模型输入与因子分数。它不是物理互作或因果网络。
- GO/Reactome对基因做ORA；代谢物用经核对的KEGG compound映射。超几何检验的背景是当前可排序的模型特征中有注释的部分，BH包含该查询所有满足最小背景大小的term（包括查询0命中者）。交互探索的不同查询各自校正，不是所有查询的联合FDR。
- 代谢物共有87/225个明确compound映射（84个唯一名称、3个核对过的同义词），66个有可用pathway成员关系；113个模糊特征和25个未匹配者不强行指定ID。默认100个模型代谢物里29个有通路注释，top20的映射可能很少。没有q<0.05时照实展示；另有“所有保留代谢物的通路覆盖”模式，不计算p值、不称为通路活性。
- GO使用明确的2024年快照；Reactome为release98；KEGG下载及每项映射的证据、版本和SHA-256见`source_audit/pathway_provenance.json`。原始mapping表在`data/metabolite_mapping.csv`。

R补充：`source('R/lab_explore.R')`后可用`compare_factor_counts()`、`factor_network()`、`factor_enrichment()`与对应的ggplot绘图函数。Rmd示例已包含这些完整计算。核心练习可留45–60分钟；新增的模型/网络/通路实验建议再留约30分钟。
