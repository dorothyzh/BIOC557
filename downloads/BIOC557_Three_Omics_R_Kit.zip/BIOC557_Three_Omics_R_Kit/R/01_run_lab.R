# Backwards-compatible entry: builds the complete default R Markdown report.
source("START_HERE.R")
