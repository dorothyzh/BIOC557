# Run from the unzipped kit root in RStudio: source('R/01_run_lab.R')
# In Terminal: Rscript R/01_run_lab.R
source('R/lab_core.R')
source('R/lab_plots.R')
source('R/lab_explore.R')
study<-read_lab_data('.')
lab<-run_lab(study,max_missing=.30,model_features=100)
# Change one preparation choice above, then run again.
# MOFA2 automatically manages its calculation dependencies. Students write only R.
runtime<-if(identical(Sys.getenv('BIOC557_USE_EXISTING_MOFA'),'1')) 'existing' else 'managed'
mofa<-fit_lab_mofa(lab,factors=3,iterations=100,seed=557,runtime=runtime)
save_lab_figures(lab,mofa)
saveRDS(list(lab=lab,mofa=mofa),'outputs/BIOC557_analysis.rds')
write.csv(mofa$scores,'outputs/mofa_scores.csv',row.names=TRUE)
write.csv(mofa$variance_explained,'outputs/mofa_factor_r2.csv',row.names=TRUE)
write.csv(lab$agreement,'outputs/cross_view_distance_agreement.csv',row.names=TRUE)
for(view in names(lab$differential))write.csv(lab$differential[[view]],file.path('outputs',paste0(view,'_differential.csv')),row.names=FALSE)
writeLines(capture.output(sessionInfo()),'outputs/R_sessionInfo.txt')
message('Saved the model, figures, scores, tables and R environment information to outputs/.')

annotations<-jsonlite::fromJSON('data/enrichment_annotations.json',simplifyVector=FALSE)
network<-factor_network(lab,mofa,factor=1,top_per_view=6)
ggplot2::ggsave('outputs/08_factor_network.png',plot_factor_network(network),width=11,height=7,dpi=220)
ora<-factor_enrichment(lab,mofa,annotations,factor=1,view='RNA',catalog='GO_BP')
ggplot2::ggsave('outputs/09_GO_candidates.png',plot_pathway_results(ora),width=11,height=6,dpi=220)
write.csv(ora$rows,'outputs/GO_candidates.csv',row.names=FALSE)
coverage<-factor_enrichment(lab,mofa,annotations,view='Metabolomics',catalog='Metabolite_pathways',mode='coverage')
ggplot2::ggsave('outputs/10_metabolite_pathway_coverage.png',plot_pathway_results(coverage),width=11,height=6,dpi=220)
write.csv(coverage$rows,'outputs/metabolite_pathway_coverage.csv',row.names=FALSE)
