# BIOC557 instructor notes · three-view R lab

1. The three matrices match by CCLE/DepMap cell-line ID, not row position. These are different assays/culture batches of the same models, not one multi-omic aliquot.
2. Existing log2 proteins, log2(TPM+1) RNA and log10 metabolites should not be logged again. Z-scoring compares model feature variation without pretending that source units are identical.
3. At defaults the retained counts are919protein,1200RNA,225metabolite;100features/view enter the factor model. Welch/BH tests cover all retained features, using observed values only.
4. Protein–RNA sample-distance agreement is about0.61; protein–metabolite and RNA–metabolite are about0.23. These are descriptive correlations of dependent distances.
5. A common factor draws substantial RNA and protein variation, while other factors have stronger metabolite contributions. Factor numbering may change between R and browser. Read the contribution plot first, then inspect weights.
6. EPCAM, VIM, EGFR and ERBB2 are preselected teaching markers. Pooled RNA–protein correlations can reflect lineage. Ask whether within-lineage patterns are equally strong before proposing regulation.
7. A shuffled row order with intact IDs can be corrected. Wrong values attached to valid IDs cannot be repaired by a simple ID check. A broken-pairing challenge need not decrease every metric.
8. Skin and Breast are cell-line lineage labels. Batch, cancer subtype and other covariates are not adjusted in the two-group comparisons. Do not frame the exercise as a patient prediction benchmark.
9. The website has independent in-memory workspaces, no shared grading or collection. Ask students to submit the exported ZIP, R script or HTML through your existing course channel.

Before class: load the website on classroom Wi-Fi, run MOFA, download the R kit, install R packages and let the managed environment prepare once. Keep the rendered HTML and prefit HDF5 as fallback. Students who cannot install packages can complete the full web exercise.

## Interactive model and annotation extensions

Use the same feature selection and preparation when comparing K. A factor number is not an identity across models; the website matches reference score patterns by absolute Spearman correlation and one-to-one assignment. Do not choose an optimal K solely from the in-sample fit curve.

Try keeping offsets, removing feature scaling, using Pareto, and scaling whole views. The center control applies across all cell lines. An uncentered high reconstruction score may largely reflect mean levels. Whole-view scaling can be subtle after unit-variance scaling.

The three per-view weight panels intentionally display the top features of weaker views as well. Check contribution values before interpreting their role. In the network, model-weight edges and observed-correlation edges are distinct; the latter pool cell-line lineages and are exploratory.

GO/Reactome use genes. The metabolite page uses uniquely matched KEGG compounds and exposes ambiguous or unmapped IDs. Default metabolite queries are small and usually have no significant ORA terms. Coverage counts are a useful separate learning activity, not evidence of pathway activation. The ORA background is each current model-view's annotated features, not every human gene/compound. BH correction is per factor/view/catalog query.
